/**
 * BSD 3-Clause License
 *
 * Copyright (C) 2018 Steven Atkinson <steven@nowucca.com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 * * Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package business.customer;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 */

public class CustomerForm {

	private String name;

	private String address;

	private String phone;

	private String email;

	private String ccNumber;

	private String ccExpiryMonth;

	private String ccExpiryYear;
	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public String getPhone() {
		return phone;
	}

	public String getEmail() {
		return email;
	}

	public String getCcNumber() {
		return ccNumber;
	}

	public String getCcExpiryMonth() {
		return ccExpiryMonth;
	}

	public String getCcExpiryYear() {
		return ccExpiryYear;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setCcNumber(String ccNumber) {
		this.ccNumber = ccNumber;
	}

	public void setCcExpiryMonth(String ccExpiryMonth) {
		this.ccExpiryMonth = ccExpiryMonth;
	}

	public void setCcExpiryYear(String ccExpiryYear) {
		this.ccExpiryYear = ccExpiryYear;
	}


	@JsonCreator
	public CustomerForm(
			@JsonProperty("name") String name,
			@JsonProperty("address") String address,
			@JsonProperty("phone") String phone,
			@JsonProperty("email") String email,
			@JsonProperty("creditCard") CreditCard creditCard) {
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.email = email;
		if (creditCard != null) {
			this.ccNumber = creditCard.getNumber();
			this.ccExpiryMonth = creditCard.getExpiryMonth();
			this.ccExpiryYear = creditCard.getExpiryYear();
		}
	}

	// Define the CreditCard nested class
	public static class CreditCard {
		private String number;
		private String expiryMonth;
		private String expiryYear;

		@JsonCreator
		public CreditCard(
				@JsonProperty("number") String number,
				@JsonProperty("expiryMonth") String expiryMonth,
				@JsonProperty("expiryYear") String expiryYear) {
			this.number = number;
			this.expiryMonth = expiryMonth;
			this.expiryYear = expiryYear;
		}

		public String getNumber() {
			return number;
		}

		public String getExpiryMonth() {
			return expiryMonth;
		}

		public String getExpiryYear() {
			return expiryYear;
		}
	}
}

